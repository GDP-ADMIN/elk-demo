<?php

namespace GitList\Exception;

class BlankDataException extends \RuntimeException
{
    
}
